﻿

using System;
using System.Drawing;

namespace HRM_App.AppCode
{
    public class BusinessObject
    {
        #region LoginForm Data      
        public int _empId { get; set; }
        public string _empName { get; set; }
        public string _userName { get; set; }
        public string _userPassword { get; set; }
        public string _role { get; set; }

        #endregion

        #region EmployeeInfoForm Data      
        public int _employeeId { get; set; }
        public string _employeeName { get; set; }
        public string _qualification { get; set; }
        public string _position { get; set; }
        public DateTime _hireDate { get; set; }
        public int _phoneNumber { get; set; }
        public int _departId { get; set;}
        public string _image { get; set; }

        #endregion

    }



}