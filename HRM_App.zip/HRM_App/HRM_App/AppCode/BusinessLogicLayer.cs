﻿
using System;
using System.Data.SqlClient;

namespace HRM_App.AppCode
{
    public class BusinessLogicLayer
    {
        public bool getUserDetail(BusinessObject getUserData, SqlConnection con)
        {

            DataAccessLayer dal = new DataAccessLayer();
            try
            {              
                return dal.FetchUserData(getUserData, dal.openSqlConnection());

            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        public bool getEmpRecord(BusinessObject empRecord)
        {

            DataAccessLayer dal = new DataAccessLayer();
            try
            {

                return dal.insertEmployeeData(empRecord, dal.openSqlConnection());

            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }
    }
}