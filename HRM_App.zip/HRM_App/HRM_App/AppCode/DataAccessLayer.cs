﻿
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;


namespace HRM_App.AppCode
{
    public class DataAccessLayer
    {
        public static string type;
        public SqlConnection openSqlConnection()
        {
            string connectionString = "Integrated Security=True;Initial Catalog = hrmDB; Data Source = DESKTOP-B1GS0NE";
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                connection.Open();
                return connection;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Someting wrong in connection: " + ex.Message);
                return null;
            }
            finally
            {
                connection.Close();
            }
        }
        
        public bool FetchUserData(BusinessObject confirmNamePassword, SqlConnection con)
        {
            try
            {

                string userQuery = "SELECT * FROM roleinfo WHERE username = @username AND userpassword = @userpassword";


                SqlCommand command = new SqlCommand(userQuery, con);
                

                    command.Parameters.AddWithValue("@username", confirmNamePassword._userName);
                    command.Parameters.AddWithValue("@userpassword", confirmNamePassword._userPassword);

                con.Open();
                using (SqlDataReader reader = command.ExecuteReader()) 
                {
                    
                    if (reader.HasRows)
                    {
                        
                        reader.Read();
                        if (reader[4].ToString() == "admin")
                        {
                            DataAccessLayer.type = "A";
                        }
                        else if (reader[4].ToString() == "attendanceEntry2")
                        {
                            DataAccessLayer.type = "B";
                        }
                        return true;
                    }

                }
                return false;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            
        }

        #region Addition and display data in Grid for Employee
        public bool insertEmployeeData(BusinessObject getEmployeeData, SqlConnection con)
        {
            SqlTransaction transaction = con.BeginTransaction();
            try
            {

                string userQuery = "insert into employeeInfo values (@employeeName,@qualification,@position,@hireDate,@phoneNumber,@departId,@Image)";

                    SqlCommand command = new SqlCommand(userQuery,con);
                    command.Parameters.AddWithValue("@employeeName", getEmployeeData._employeeName);
                    command.Parameters.AddWithValue("@qualification", getEmployeeData._qualification);
                    command.Parameters.AddWithValue("@position", getEmployeeData._position );
                    command.Parameters.AddWithValue("@hireDate", getEmployeeData._hireDate );
                    command.Parameters.AddWithValue("@phoneNumber", getEmployeeData._phoneNumber );
                    command.Parameters.AddWithValue("@departId", getEmployeeData._departId );
                    command.Parameters.AddWithValue("@Image", getEmployeeData._image);
                command.Transaction = transaction;
                int a = command.ExecuteNonQuery();
                if (a > 0)
                {
                    transaction.Commit();
                    return true;                    
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                throw ex;
            }
            
        }


        public DataTable bindGrid(SqlConnection con)
        {

            string query = "select * from employeeInfo";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
                       
        }

        public DataTable bindDepartDDL(SqlConnection con)
        {
            string query = "select * from department";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        #endregion

        public int gridRowCommandForSingleRecord(BusinessObject getEmployeeData, SqlConnection con)
        {
                string selectQuery = "SELECT * FROM employeeInfo WHERE empId = @empId";              
                SqlCommand cmd = new SqlCommand(selectQuery, con);

                cmd.Parameters.AddWithValue("@empId", getEmployeeData._employeeId);

                 con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                
                if (reader.Read())
                {

                getEmployeeData._employeeId = Convert.ToInt32(reader["empId"]);
                getEmployeeData._employeeName = reader["empName"].ToString();
                getEmployeeData._qualification = reader["qualification"].ToString();
                getEmployeeData._position = reader["position"].ToString();
                getEmployeeData._hireDate = Convert.ToDateTime(reader["hireDate"]);
                getEmployeeData._phoneNumber = Convert.ToInt32(reader["phoneNumber"]);
                getEmployeeData._departId = Convert.ToInt32(reader["departId"]);
                getEmployeeData._image = reader["Image"].ToString();
            }
                
               return getEmployeeData._employeeId;
        }

        public bool updateEmployeeData(BusinessObject getEmployeeData, SqlConnection con)
        {
            SqlTransaction transaction = con.BeginTransaction();
            try
            {

                string query = @"update employeeInfo set empName =@employeeName, qualification=@qualification, position=@position,
                                    hireDate = @hireDate, phoneNumber = @phoneNumber, departId = @departId, Image = @Image
                                    where empId = @employeeId";
                SqlCommand cmd = new SqlCommand(query,con);
               
               
                cmd.Parameters.AddWithValue("@employeeId", getEmployeeData._employeeId);
                cmd.Parameters.AddWithValue("@employeeName", getEmployeeData._employeeName);
                cmd.Parameters.AddWithValue("@qualification", getEmployeeData._qualification);
                cmd.Parameters.AddWithValue("@position", getEmployeeData._position);
                cmd.Parameters.AddWithValue("@hireDate", getEmployeeData._hireDate);
                cmd.Parameters.AddWithValue("@phoneNumber", getEmployeeData._phoneNumber);
                cmd.Parameters.AddWithValue("@departId", getEmployeeData._departId);
                cmd.Parameters.AddWithValue("@Image", getEmployeeData._image);

                cmd.Transaction = transaction;
                int a = cmd.ExecuteNonQuery();              
                
                if (a > 0)
                {
                    transaction.Commit();
                    return true;                
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                throw ex;
            }
            
        }

        public bool deleteEmployeeData(BusinessObject getEmployeeData, SqlConnection con)
        {
            SqlTransaction transaction = con.BeginTransaction();
            try
            {
                string query = "delete from employeeInfo where empId=@employeeId";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@employeeId", getEmployeeData._employeeId);
                cmd.Transaction = transaction;
                int a = cmd.ExecuteNonQuery();

                if (a > 0)
                {
                    transaction.Commit();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                throw ex;
            }
           
        }      

    }
}