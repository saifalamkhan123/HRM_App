﻿
using HRM_App.AppCode;
using System;
using System.Data;
using System.IO;
using System.Web.UI.WebControls;

namespace HRM_App.Forms
{
    public partial class EmpProfileForm : System.Web.UI.Page
    {
        DataAccessLayer dal = new DataAccessLayer();
        BusinessObject bo = new BusinessObject();
        BusinessLogicLayer bl = new BusinessLogicLayer();
        protected void Page_Load(object sender, EventArgs e)
        {
            nameTextBox.Focus();


            DataTable dtGrid = dal.bindGrid(dal.openSqlConnection());
            gdEmpProfile.DataSource = dtGrid;
            gdEmpProfile.DataBind();

            if (!IsPostBack)
            {

                DataTable dt = dal.bindDepartDDL(dal.openSqlConnection());

                if (dt != null && dt.Rows.Count > 0)
                {
                    departDDL.DataSource = dt;
                    departDDL.DataValueField = "id";
                    departDDL.DataTextField = "departName";
                    departDDL.DataBind();

                    ListItem selectItem = new ListItem("Select Department", "");
                    departDDL.Items.Insert(0, selectItem);
                }

            }
        }

        protected void saveButton_Click(object sender, EventArgs e)
        {
            try
            {

                string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.SaveAs(Server.MapPath("~/Forms/images/" + filename));
                bo._employeeName = nameTextBox.Text;
                bo._qualification = qualificationTextBox.Text;
                bo._position = positionTextBox.Text;
                bo._hireDate = Convert.ToDateTime(hireDateTextBox.Text);
                bo._phoneNumber = Convert.ToInt32(phoneTextBox.Text);
                bo._departId = Convert.ToInt32(departDDL.SelectedValue);
                bo._image = "images/" + filename;

                bool isInsertSucces = bl.getEmpRecord(bo);

                if (isInsertSucces)
                {
                    Response.Write("<script>alert('Record inserted successfully');</script>");
                    DataTable dtGrid = dal.bindGrid(dal.openSqlConnection());
                    gdEmpProfile.DataSource = dtGrid;
                    gdEmpProfile.DataBind();

                }
                else
                {
                    Response.Write("<script>alert('Please Try Again');</script>");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void pickDate_Click(object sender, EventArgs e)
        {
            hireDateTextBox.Visible = true;
        }

        protected void datePicker_SelectionChanged(object sender, EventArgs e)
        {
            hireDateTextBox.Text = datePicker.SelectedDate.ToLongDateString();
            datePicker.Visible = false;

        }

        protected void addButton_Click(object sender, EventArgs e)
        {

            Response.Redirect("EmpProfileForm.aspx");

        }

        protected void refreshButton_Click(object sender, EventArgs e)
        {

            Response.Redirect("EmpProfileForm.aspx");

        }

        protected void gdEmpProfile_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                int id = Convert.ToInt32(e.CommandArgument);

                bo._employeeId = id;
                dal.gridRowCommandForSingleRecord(bo, dal.openSqlConnection());

                nameTextBox.Text = bo._employeeName;
                qualificationTextBox.Text = bo._qualification;
                positionTextBox.Text = bo._position;
                hireDateTextBox.Text = bo._hireDate.ToString();
                phoneTextBox.Text = bo._phoneNumber.ToString();
                departDDL.SelectedValue = bo._departId.ToString();

            }
        }

        protected void updateButton_Click(object sender, EventArgs e)
        {
            try
            {
                string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                int rowIndex = gdEmpProfile.SelectedIndex;
                int empId = Convert.ToInt32(gdEmpProfile.DataKeys[rowIndex].Value);

                FileUpload1.SaveAs(Server.MapPath("~/Forms/images/" + filename));
                
                bo._employeeId = empId;
                bo._employeeName = nameTextBox.Text;
                bo._qualification = qualificationTextBox.Text;
                bo._position = positionTextBox.Text;
                bo._hireDate = DateTime.Parse(hireDateTextBox.Text);
                bo._phoneNumber = Convert.ToInt32(phoneTextBox.Text);
                bo._departId = Convert.ToInt32(departDDL.SelectedValue);
                bo._image = "images/" + filename;

                bool isInsertSucces = dal.updateEmployeeData(bo, dal.openSqlConnection());

                if (isInsertSucces)
                {
                    Response.Write("<script>alert('Record updated successfully');</script>");
                    DataTable dtGrid = dal.bindGrid(dal.openSqlConnection());
                    gdEmpProfile.DataSource = dtGrid;
                    gdEmpProfile.DataBind();

                }
                else
                {
                    Response.Write("<script>alert('Please Try Again');</script>");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                
                int rowIndex = gdEmpProfile.SelectedIndex;
                int empId = Convert.ToInt32(gdEmpProfile.DataKeys[rowIndex].Value);
                bo._employeeId = empId;
                
                bool isInsertSucces = dal.deleteEmployeeData(bo, dal.openSqlConnection());

                if (isInsertSucces)
                {
                    Response.Write("<script>alert('Record deleted successfully');</script>");
                    DataTable dtGrid = dal.bindGrid(dal.openSqlConnection());
                    gdEmpProfile.DataSource = dtGrid;
                    gdEmpProfile.DataBind();

                }
                else
                {
                    Response.Write("<script>alert('Please Try Again');</script>");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void exitButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("DashBoardForm.aspx");
        }
    }
}