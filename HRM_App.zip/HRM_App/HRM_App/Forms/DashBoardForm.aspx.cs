﻿using HRM_App.AppCode;
using System;


namespace HRM_App.Forms
{
    public partial class DashBoardForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
               
                if (Session["name"] != null)
                {
                    string userName = Session["name"].ToString();                 
                    lblWelcomeMessage.Text = "Welcome "+ userName +" to HRM Application";
                }
               
            }


            if (DataAccessLayer.type=="A")
            {

                btnAttendance.Enabled = true;
                btnEmpInfo.Enabled = true;
                btnLogOut.Enabled = true;
                btnPayroll.Enabled = true;
            }

            else if (DataAccessLayer.type == "B")
            {

                btnAttendance.Enabled = true;
                btnEmpInfo.Enabled = false;
                btnLogOut.Enabled = true;
                btnPayroll.Enabled = false;
            }

        }

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginForm.aspx");
        }

        protected void btnEmpInfo_Click(object sender, EventArgs e)
        {

            Response.Redirect("EmpProfileForm.aspx");

        }
    }
}