﻿
using HRM_App.AppCode;
using System;


namespace HRM_App.Forms
{
    public partial class LoginForm : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            txt_Username.Focus();
        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
            BusinessObject bo = new BusinessObject();
            bo._userName = txt_Username.Text;
            bo._userPassword = txt_password.Text;        

            BusinessLogicLayer bl = new BusinessLogicLayer();
            DataAccessLayer dal = new DataAccessLayer();
           
            try
            {
                bool result = Convert.ToBoolean(bl.getUserDetail(bo, dal.openSqlConnection()));

                if (result == true)
                {
                    Session["name"] = txt_Username.Text;
                    Response.Redirect("DashBoardForm.aspx");
                }
                else
                {
                    Response.Write("<script>alert('You are not authorized');</script>");                  
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }

        protected void btn_cancel_Click(object sender, EventArgs e)
        {
            txt_Username.Text = "";
            txt_password.Text = "";
            txt_Username.Focus();
        }
    }
}